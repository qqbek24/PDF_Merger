TkinterDnD2 Package
===================

:mod:`TkinterDnD2` Module
-------------------------

.. automodule:: TkinterDnD2.TkinterDnD
    :members:
    :undoc-members:
    :show-inheritance:

:class:`DnDEvent` Class
-----------------------

.. autoclass:: TkinterDnD2.TkinterDnD.DnDEvent
    :members:
    :undoc-members:
    :show-inheritance:

:class:`DnDWrapper` Class
-------------------------
.. autoclass:: TkinterDnD2.TkinterDnD.DnDWrapper
    :members:
    :undoc-members:
    :show-inheritance:

:class:`TixTk` Class
-----------------------
.. autoclass:: TkinterDnD2.TkinterDnD.TixTk
    :members:
    :undoc-members:
    :show-inheritance:

:class:`Tk` Class
-----------------------
.. autoclass:: TkinterDnD2.TkinterDnD.Tk
    :members:
    :undoc-members:
    :show-inheritance: