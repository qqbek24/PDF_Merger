.. tkinterdnd2 documentation master file, created by
   sphinx-quickstart on Wed Feb 19 10:27:56 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to tkinterdnd2's documentation!
=======================================

`klappnase' TkinterDnD2 <http://tkinterdnd.sourceforge.net>`_ is a python wrapper for `George Petasis' tkDnD Tk 
extension version 2 <hhttps://github.com/petasis/tkdnd>`_.

Here we packaged TkinterDnD2 and tkdnd2 into a standard python module. When it is imported in python
the Tk extension location is automatically added to the Tk search path.

.. toctree::
   :maxdepth: 2
   :caption: Contents:
   
   TkinterDnD2.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
